// jest.setup.js
jest.setTimeout(30000);
process.env.NODE_ENV = process.env.NODE_ENV || 'test';
